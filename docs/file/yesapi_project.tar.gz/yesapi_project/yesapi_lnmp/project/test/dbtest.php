<?php 
 $dsn="mysql:host=mysql01;dbname=information_schema";//这就是数据源,
    $user="root";//这个是服务器的账号，我的电脑上是这样，就不知道你们的是不是，
    $pwd="123456";//这是我电脑上的服务器密码,就是我没设
    $pdo=new \PDO($dsn,$user,$pwd);//实例化一个PDO连接
    $pdo->query("set names gbk");//设置从数据库里面传递过来的数据的编码格式

$sql="SHOW PROCESSLIST;";
$shuju=$pdo->prepare($sql);//这就是我们所说的预处理
$shuju->execute();//执行预处理的结果;
$jg=$shuju->fetchall(\PDO::FETCH_ASSOC);
$hangshu=count($jg);//数出结果集的行数
if($hangshu>0){
    echo '数据库可以正常连接成功';
} 

