<?php
 phpinfo();
